How To Use:
...........

First place bank files into the bank folder you want to extract. Once extracted, 
you will find the wav files in the wav folder with another folder with the same 
name as the bank file.

To rebuild the bank files, you will need to replace the wav files with your own 
and if you want, you can edit the txt file to your new wav file names. After that 
click Rebuild.

Version History:
----------------

0.0.1.4 - Complete code overhaul and new Fmod api, Improved FSB Info and can now play tracks when double clicking them. Should be no crashing now. 
0.0.1.3 - Fixed a problem loading large bank files.
0.0.1.2 - Added FMOD Bank Profile to Options and FSB Info.
0.0.1.1 - Fixed a crashing bug.
0.0.1.0 - Initial Release